# Kindy Banks Cloud (demo)

## What this is
A small demo Node.js app that accepts uploaded website files and serves them at generated URLs.

- Upload files via the web form at `/`.
- Project page (tries `index.html`) at `/p/<id>`.
- Raw files served at `/u/<id>/<filename>`.

This is meant as an educational starting point. For production use:
- Use cloud object storage (S3, GCS, etc.)
- Add authentication, input validation, file-type checks, and rate limiting
- Serve over HTTPS with a proper domain (e.g. kindybanks.cloud)

## Quick start (local)
1. Install Node.js (v16+ recommended).
2. In project folder run:
   ```bash
   npm install
   npm start
   ```
3. Open `http://localhost:3000` in your browser.

## Deploying
- You can deploy to Render, Railway, or similar platforms.
- If you host at `https://kindybanks.cloud`, set environment variable `PLACEHOLDER_DOMAIN=kindybanks.cloud` if you want links to show that domain.
