/**
 * Kindy Banks Cloud - simple uploader
 * - Upload files (html, css, js, images... )
 * - Each upload is stored in /uploads/<id>/
 * - Visit /u/<id>/<filename> to view files, or /p/<id> to open index.html
 *
 * NOTE: This is a minimal example for learning and small projects.
 * For production, add security, input validation, rate limiting, and a proper storage backend (S3).
 */
const express = require('express');
const multer = require('multer');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

const app = express();
const PORT = process.env.PORT || 3000;
const UPLOADS_DIR = path.join(__dirname, 'uploads');

app.use(express.static('public'));

// Ensure uploads dir exists
if (!fs.existsSync(UPLOADS_DIR)) fs.mkdirSync(UPLOADS_DIR);

// Multer storage - store in memory then write to a new id folder
const storage = multer.memoryStorage();
const upload = multer({ storage: storage });

// Helper - generate short id
function shortId() {
  return crypto.randomBytes(4).toString('hex');
}

// Upload endpoint - accepts multiple files (a full website)
// field name: files
app.post('/upload', upload.array('files'), (req, res) => {
  if (!req.files || req.files.length === 0) {
    return res.status(400).send('No files uploaded.');
  }
  const id = shortId();
  const dir = path.join(UPLOADS_DIR, id);
  fs.mkdirSync(dir, { recursive: true });

  // Save each file into the id directory
  req.files.forEach(file => {
    // Prevent directory traversal by taking basename
    const filename = path.basename(file.originalname);
    const dest = path.join(dir, filename);
    fs.writeFileSync(dest, file.buffer);
  });

  // URL placeholders: the app will serve files at /u/<id>/<filename>
  // and will try to open index.html at /p/<id>
  const placeholderDomain = process.env.PLACEHOLDER_DOMAIN || 'kindybanks.cloud';
  const host = req.get('host') || placeholderDomain;
  const base = `${req.protocol}://${host}`;
  const projectUrl = `${base}/p/${id}`;
  const rawBase = `${base}/u/${id}`;
  res.send(\`
    <h2>Upload complete</h2>
    <p>Project ID: <strong>\${id}</strong></p>
    <p>Open the project (tries index.html): <a href="\${projectUrl}">\${projectUrl}</a></p>
    <p>Direct file base URL: <a href="\${rawBase}">\${rawBase}</a></p>
    <p>To upload again, go back to <a href="/">Home</a>.</p>
  \`);
});

// Serve files under /u/:id/<filename>
app.use('/u/:id', (req, res, next) => {
  const id = req.params.id;
  const filePath = path.join(UPLOADS_DIR, id, req.path);
  // Normalize and check
  if (!filePath.startsWith(path.join(UPLOADS_DIR, id))) {
    return res.status(400).send('Invalid path');
  }
  fs.stat(filePath, (err, stats) => {
    if (err) return res.status(404).send('Not found');
    res.sendFile(filePath);
  });
});

// Shortcut to open index.html (or list files) at /p/:id
app.get('/p/:id', (req, res) => {
  const id = req.params.id;
  const indexPath = path.join(UPLOADS_DIR, id, 'index.html');
  if (fs.existsSync(indexPath)) {
    return res.sendFile(indexPath);
  }
  // Fallback: list files
  const dir = path.join(UPLOADS_DIR, id);
  if (!fs.existsSync(dir)) return res.status(404).send('Project not found');
  const files = fs.readdirSync(dir);
  const list = files.map(f => \`<li><a href="/u/\${id}/\${encodeURIComponent(f)}">\${f}</a></li>\`).join('');
  res.send(\`<h2>Files for project \${id}</h2><ul>\${list}</ul>\`);
});

// Simple home page
app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

// Start
app.listen(PORT, () => {
  console.log('Kindy Banks Cloud running on port', PORT);
});
